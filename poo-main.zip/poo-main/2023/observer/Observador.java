package observer;

public interface Observador {
	public void actualizar(String mensaje);
}
