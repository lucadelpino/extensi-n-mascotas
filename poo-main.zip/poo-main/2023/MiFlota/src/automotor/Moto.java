package automotor;

public class Moto extends Vehiculo {
	
	public Moto() {
		// TODO Auto-generated constructor stub
	}
	
	public void mostrar() {
		super.mostrar();
	}
	

}
