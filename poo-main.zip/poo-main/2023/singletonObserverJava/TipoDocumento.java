package singletonObserverJava;

public enum TipoDocumento {
	DNI, 
	LC, 
	LE, 
	PASS, 
	OTROS
}