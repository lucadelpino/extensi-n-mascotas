package singletonObserverJava;

public class EmpleadoBanco extends Persona {

	private int numeroLegajo;

	public int getNumeroLegajo() {
		return numeroLegajo;
	}

	public void setNumeroLegajo(int numeroLegajo) {
		this.numeroLegajo = numeroLegajo;
	}
}
