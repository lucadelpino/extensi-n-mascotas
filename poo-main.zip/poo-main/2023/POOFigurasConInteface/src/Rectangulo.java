
public class Rectangulo implements IFiguraGeometrica {

	public Rectangulo() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void dibujar() {
		System.out.println("Me dibujo, soy un rectángulo");
	}

	@Override
	public void saludar() {
		System.out.println("Saludo rectángulo");

	}

}
