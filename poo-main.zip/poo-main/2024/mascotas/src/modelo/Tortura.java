package modelo;

public class Tortura extends Mascota {

	@Override
	public void lucirme() {
		// TODO Auto-generated method stub

	}

}
