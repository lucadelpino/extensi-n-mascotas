package modelo;

public interface IVacunable {
	public void vacunar();
}
