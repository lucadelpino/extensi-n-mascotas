package miStrategy;

public abstract class CuponDescuento {
	
	public abstract void calcularDescuento();
	
}
