package miDecorator;

public interface Auto {
	public void arracar();
	public void frenar();
	public void acelerar();

}
