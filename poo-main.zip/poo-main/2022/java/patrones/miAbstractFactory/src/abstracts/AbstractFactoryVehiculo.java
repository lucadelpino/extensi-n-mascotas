package abstracts;

public abstract class AbstractFactoryVehiculo {
	
	public abstract AbstractAuto crearAuto();
	
	
	public abstract AbstractMoto crearMoto();
}
