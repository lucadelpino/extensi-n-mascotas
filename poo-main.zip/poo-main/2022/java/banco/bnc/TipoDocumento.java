package bnc;

public enum TipoDocumento {
	DNI, DU, LE
}
