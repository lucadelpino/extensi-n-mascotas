package zoo;

public abstract class Animal {	
	
	public void caminar() {
		System.out.println("Soy un animal y estoy caminando");
	}
	
	public abstract void sonar();
}