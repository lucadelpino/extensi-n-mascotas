package zoo;

public interface Mascota {
	
	public void darPatita(String s);
	public void jugar();
}
